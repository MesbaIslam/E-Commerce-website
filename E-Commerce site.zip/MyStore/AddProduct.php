<?php
	include 'db.php';

?>

<!DOCTYPE html>
<html>
<head>
	<?php include 'includes/head.php';?>
	<Style>
		.header{
			width: 100%;
			margin:50px auto 0px;
			margin-top: -1%;
			color:white;
			background: #db0f2d;
			text-align: center;
			border:1px solid #db0f2d;
			border-bottom: none;
			border-radius: 10px 10px 0px 0px;
			padding: 20px;
			font-size: 20px;
			font-style: italic;
			font-family: Bookman Old Style;
		}

		body{
			font-size: 140%;
			height: 100%;
			background-repeat: no-repeat;
			background-size: cover;

		}
		#box{
			width: 270px;
			margin-left: 10%;
		}

		#admin{
			width: 150%;
			height: 100%;
			margin-left: 20%;
		}
		td{
			font-family: Bookman Old Style;
			font-size: 17px;
		}
		

	</Style>
</head>
<body>
<nav class="navbar navbar-inverse" id="HomeNav" id="cartNav">
    <div class="container-fluid">
      <ul class="nav navbar-nav">
        <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="about.php"><span class="glyphicon glyphicon-exclamation-sign"></span> About</a></li>
        <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> Contact</a></li>
        <li style="width:300px;left:10px;top:10px;"><input type="text" class="form-control" id="search"></li>
        <li style="top:10px;left:20px;"><button class="btn btn-primary" id="search_btn">Search</button></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
 			<li><a href="logout.php" style="text-decoration:none">Logout</a></li>
				
	 </ul>
 </nav>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
		<div class="panel panel-primary" id="admin">
			<div class="header">Add Product</div>
				<div class="panel-body">
									
					<form action="" method="post" enctype="multipart/form-data">
						<table style="margin-left: 15%">
							<tr>
								<td>Product Category</td>
								<td><input type="text" name="pro_cat" id="box"/></td>
							</tr>

							<tr>
								<td>Product Brand</td>
								<td><input type="text" name="pro_brand" id="box"/></td>
							</tr>

							<tr>
								<td>Product Title</td>
								<td><input type="text" name="pro_title" id="box"/></td>
							</tr>

							<tr>
								<td>Product Price</td>
								<td><input type="text" name="pro_price" id="box"/></td>
							</tr>

							<tr>
								<td>Product Description</td>
								<td><input type="text" name="pro_desc" id="box"/></td>
							</tr>

							<tr>
								<td>Product Image</td>
								<td><input type="file" name="file_img" id="box"/></td>
							</tr>

							<tr>
				 				<td>Product Keywords</td>
				 				<td><input type="text" name="pro_keywords" id="box"/></td>
				 			</tr>

				 			<tr>
				 				<td>Product List Price</td>
				 				<td><input type="text" name="pro_listPrice" id="box"/></td>
				 			</tr> 	

				 			<tr>
				 				<td colspan="2" align="center"><input type="submit" name="btn_upload" value="upload" style="margin-left: 15%"></td>
				 			</tr>			

						</table>
						<br><br>

				    </form>


				</div>
			
		</div>
			
		</div>
		
	</div>
	
</div>



<?php 
	if(isset($_POST['btn_upload']))
	{
		$filetmp = $_FILES["file_img"]["tmp_name"];
		$filename = $_FILES["file_img"]["name"];
		//$filetype = $_FILES["file_img"]["type"];
		$filepath ="/". $filename;

	//	move_uploaded_file($filetmp, $filepath);

		$sql = "INSERT INTO  products (product_id, product_cat, product_brand, product_title, product_price, product_desc, product_image, product_keywords, product_listPrice) VALUES
		(' ', '$_POST[pro_cat]', '$_POST[pro_brand]', '$_POST[pro_title]', '$_POST[pro_price]' , '$_POST[pro_desc]', '$filepath', '$_POST[pro_keywords]', '$_POST[pro_listPrice]')";

		$result = mysqli_query($con, $sql);

			echo "<p style='margin-left:15% ; font-family:Bookman Old Style'>Product Added Successfully</p>";
			
	} else{
		echo "<p style='margin-left:15% ; font-family:Bookman Old Style'>Couldn't add the product</p>";
	
	}

?>



</body>
</html>