<?php
include 'customer_registration.php'; 
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<?php include 'includes/head.php'; ?>

		<style>
 		 /* Column container */
		.row {  
		    display: flex;
		    flex-wrap: wrap;
		}
		/* Main column */
		.main {   
		    flex: 80%;
		    background-color: white;
		    margin-left: 20%;
		}

		 #HomeNav{
		    margin-left: 19%;
		 }
		 #TopHead{
			width: 100%;
			margin:50px auto 0px;
			margin-top: -1%;
			color:white;
			background: #db0f2d;
			text-align: center;
			border:1px solid #db0f2d;
			border-bottom: none;
			border-radius: 10px 10px 0px 0px;
			padding: 10px;
			font-size: 20px;
			font-style: italic;
			font-family: Bookman Old style;
		}


		</style>

	</head>

<body>
<!--<div class="wait overlay">
	<div class="loader"></div>
</div> --> 
	<?php include 'includes/HeadNav.php';?>
	
	<?php include 'includes/SideNav.php'; ?>

		<div class="container-fluid">
		<div class="row">
			<div class="col-md-1"></div>
			
			<div class="col-md-8">	
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg"></div>
				</div>
				<div class="panel panel-info" id="scroll" style="margin-left: 23%; width: 110%">
					<div class="panel-heading" id="TopHead"> Exclusive Products</div>
					<div class="panel-body" >
						<div id="get_product">
							<!--Here we get product jquery Ajax Request-->
						</div>
					</div>
					</div>
			</div>
			<div class="col-md-1"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<center>
					<ul class="pagination" id="pageno">
						<li><a href="#">1</a></li>
					</ul>
				</center>
			</div>
		</div>
	</div>
</body>
<footer>
<div>
    <p>&copy; All rights reserved by Shopaholic BD </p>
  </div>
</footer>
</html>



