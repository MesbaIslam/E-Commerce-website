
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Shopaholic BD</title>
  <?php include 'includes/head.php';  ?>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    #HomeNav {
    margin-left: 19%; 
  }
  .text{
    flex: 60%;
    background-color: white;
    margin-left: 20%;
  }
  </style>
  

</head>

<body>
  <?php include 'includes/HeadNav.php'; ?>
  <?php include 'includes/SideNav.php'; ?>


<!---about -->
<div class="container">
<div class="text" > 
<h1 style="text-align: center"> ShopaholicBD </h1>
  <p style="text-align: center"> This will be an online website that will provide all the goods for anyone who wishes to purchase goods without going to the market. The website will allow people to make multiple searches at the same time. This will save their time as they do not need to scroll multiple pages. The website will also have a customer database. The customer can login with their facebook id and puchase. A purchase history will be saved after each puchase.
  </p>
</div>

</div>


</body>


<footer>
  <div>
    <p>&copy; All rights reserved by Shopaholic BD </p>
  </div>
</footer>
</html>

​