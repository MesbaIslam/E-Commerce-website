<!DOCTYPE html>
<html lang="en">

<head>
  <title>Shopaholic BD</title>
  <?php include 'includes/head.php';  ?>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    #HomeNav {
    margin-left: 19%; 
  }
  .main{
    flex: 70%;
    background-color: white;
    margin-left: 20%;
  }
  </style>
</head>
  

<body>
<?php include 'includes/HeadNav.php'; ?>

<?php include 'includes/SideNav.php'; ?>


<div class="main" style="margin-left: 25%"> 
  <div class="contact">
    <h2> Contact us: </h2>
    <P>IRIN AKTER : <br>
      <a href="mailto:ridinakter@gmail.com?Subject=Hello%20again" target="_top"><span class="glyphicon glyphicon-envelope"> ridinakter@gmail.com</span></a>  
      <span class="glyphicon glyphicon-earphone">01917746643</span>
    </P>
    <P> SAILANJAN BARUA: <br>
      <a href="mailto:sailanjanbaruar@gmail.com?Subject=Hello%20again" target="_top"><span class="glyphicon glyphicon-envelope"> sailanjanbarua@gmail.com</span></a>  
      <span class="glyphicon glyphicon-earphone">01843666673</span>
    </P>

    <P> MESBAHUL ISLAM: <br>
       <a href="mailto:nauvro@gmail.com?Subject=Hello%20again" target="_top"><span class="glyphicon glyphicon-envelope"> nauvro@gmail.com</span></a> 
       <span class="glyphicon glyphicon-earphone">01682031156</span>
    </P>

    <P> KAZI SHEHMAZ ISLAM: <br>
      <a href="mailto:shehmaz123@gmail.com?Subject=Hello%20again" target="_top"><span class="glyphicon glyphicon-envelope"> shehmaz123@gmail.com</span></a>
      <span class="glyphicon glyphicon-earphone">01912682712</span>
    </P>
  </div>
</div>

</body>
<footer>
  <div>
    <p>&copy; All rights reserved by Shopaholic BD </p>
  </div>
</footer>

</html>
