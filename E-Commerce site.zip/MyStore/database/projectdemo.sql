-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2018 at 07:41 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectdemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'Ridita', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'HP'),
(2, 'Samsung'),
(3, 'Apple'),
(4, 'Sony'),
(5, 'LG'),
(6, 'Cloth Brand');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(9, 1, '::1', 1, 1),
(10, 14, '::1', 1, 1),
(11, 15, '::1', 1, 1),
(12, 68, '::1', 2, 1),
(13, 70, '::1', 2, 1),
(14, 3, '::1', 2, 1),
(15, 1, '::1', 2, 1),
(16, 2, '::1', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Women'),
(2, 'Men'),
(3, 'Kids'),
(4, 'Smart Phone & Accessories'),
(5, 'Health & Beauty'),
(6, 'Books'),
(7, 'Jewelries & Watches'),
(8, 'Electronics'),
(9, 'Bags');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  `product_listPrice` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`, `product_listPrice`) VALUES
(1, 1, 'Sabyasachi', 'Saree', 150, 'Sabyasachi Saree conllection', 'women/saree.jpg', 'women clothes', 160),
(2, 4, 'apple', 'iPhone 5s', 199, 'iphone 5s', 'iphone mobile.jpg', 'mobile ', 210),
(3, 2, 'Gucci', 'Suit', 45, 'Gents suits', 'suit.jpg', 'suit', 50),
(4, 1, 'Miami', 'Cardigan', 5, 'Winter collection - Ladies Sweater', 'women/women5.jpg', 'sweater', 7),
(5, 1, 'Levis', 'Denims', 13, 'ladies denims', 'women7.jpg', 'denims', 16),
(6, 8, 'HP', 'Hp Laptop ', 500, 'Hp Red and Black combination Laptop', 'electronics/laptop.jpg', 'laptop', 530),
(7, 8, 'HP', 'Laptop Pavillion', 600, 'Laptop Hp Pavillion', 'laptop2.jpg', 'laptop', 630),
(8, 1, 'NE Fashion', 'Ladies Coat', 24, 'NE PEOPLE Womens Lightweight Quilted Zip Jacket/Vest', 'women/coat.jpg', 'coat', 27),
(9, 4, 'apple', 'iPad', 329, 'ipad apple brand', 'ipad.jpg', 'ipad', 332),
(10, 1, 'Yellow', 'Floral shirt', 49, 'Floral Shirt', 'women1.jpg', 'clothes', 52),
(11, 1, 'Persona', 'Red Dress', 50, 'Red dress', 'women/dress.jpg', 'women clothes', 54),
(13, 1, 'Sabyasachi', 'Lahenga', 90, 'Lahenga', 'women/lehenga.jpg', 'women clothes', 93),
(14, 8, 'Phillips', 'Iron Machine', 4, 'phillips', 'iron.jpg', 'iron', 5),
(15, 8, 'Phillips', 'Coffee Maker', 5, 'phillips', 'cofee.jpg', 'coffee maker', 6),
(16, 2, 'Red & taylor', 'Party Suit', 70, 'Formal Party Wear Suit', 'men/suit.jpg', 'suit', 73),
(17, 2, 'Red & taylor', 'Gents Coat', 70, 'gents coat', 'men/coat.jpg', 'mens clothes', 73),
(18, 2, 'Red & taylor', 'Shirt', 28, 'gents coat', 'men/shirt.jpg', 'mens clothes', 32),
(19, 3, 'Hello Kitty', 'Hair Band ', 2, 'hair band', 'kids/hairBand.jpg', 'hair band ', 3),
(20, 2, 'Royal Wear', 'Mens Sweater', 30, 'sweater', 'Winter-fashion-men-burst-sweater.png', 'sweater', 34),
(21, 2, 'Levis', 'Casual Pant', 23, 'pant', 'men/pant.jpg', 'pant', 26),
(24, 3, 'Yellow', 'Blue T shirt', 10, 'blue T shirt', 'images.jpg', 'kids dress', 11),
(25, 3, 'Kya Kraft', 'Salwar Kamiz', 13, 'yellow girls dress', 'images (3).jpg', 'kids dress', 15),
(26, 3, 'Yellow', 'Skyblue dress', 11, 'skyblue dress', 'kids-wear-121.jpg', 'kids dress', 13),
(27, 3, 'Yellow', 'Formal look', 14, 'formal look', 'image28.jpg', 'kids dress', 15),
(28, 7, 'cK', 'Ladies Watch', 20, 'watch', 'jewelry/watch2.jpg', 'ladies watch', 25),
(29, 7, 'Rolex', 'Gents Watch', 40, 'Rolex Watches', 'jewelry/watch.jpg\r\n', 'Gents Watch', 43),
(30, 7, 'Diamond world', 'Pendant ', 100, 'Pendant', 'jewelry/pendant.jpg', 'pendant', 120),
(31, 7, 'Diamond World', 'Necklace', 350, 'Beautiful jewelry', 'jewelry/necklace.jpg', 'necklace', 380),
(32, 5, 'Himalaya', 'Hair oil', 50, 'Hair oil', 'beauty/hair oil 2.jpg', 'oil', 52),
(33, 8, 'LG', 'Refrigerator', 450, 'Refrigerator', 'fridge.jpg', 'refrigerator samsung', 470),
(34, 4, 'apple', 'iPhone 6s', 400, 'Apple iPhone ', 'iphone mobile.jpg', 'iphone ', 440),
(35, 3, 'Vouge', 'Girls Frock', 12, 'frock', 'kids/frock.jpg', 'frock', 14),
(37, 8, 'samsung', 'LED TV', 190, 'LED TV', 'led.jpg', 'led tv lg', 200),
(38, 8, 'samsung', 'Microwave Oven', 25, 'Microwave Oven', 'oven.jpg', 'Microwave Oven', 30),
(39, 5, 'Mac', 'Skin care combo', 55, 'Moisturizer, face-wash, toner  ', 'beauty/skin.jpg', 'skin', 58),
(40, 5, 'Mac', 'Mac cosmetics', 70, 'Foundation shades 01, 02, 03 ', 'beauty/mac2.jpg', 'skin', 72),
(41, 5, 'Milani', 'Milani Lipsticks', 16, 'Shades: Fling, Berry Me, Soothing ', 'beauty/lipstick.jpg', 'Lipstick', 18),
(42, 5, 'Elf', 'Elf EyeLiner', 13, 'Elf Eye liner', 'beauty/liner.jpg', 'EyeLiner', 15),
(43, 4, 'Xiomi', 'Mi 6', 577, 'internal memory  4gb', 'Phone/Mi_6.JPG', 'Mi_6 ', 580),
(44, 4, 'Xiomi', 'Mi- Power Bank', 22, '10000mAh Power Bank', 'Phone/powerBank.jpg', 'power bank', 24),
(45, 4, 'Sony', 'Wireless Head Phones', 348, '10000mAh Power Bank', 'Phone/headPhone.jpg', 'head phones', 354),
(46, 4, 'Samsung', 'Samsung Galaxy Note 3', 690, 'internal memory  4gb', 'samsung_galaxy_note3_note3neo.JPG', 'samsung galxaxy note 3 ', 700),
(47, 6, 'By Dan Brown', 'Origin', 4, 'Origin by Dan Brown', 'books/Origin.jpg', 'book', 5),
(48, 5, 'Dove', 'Shampoo', 40, 'Shampoo 489ml', 'beauty/shampoo.jpg', 'shampoo', 43),
(49, 6, 'By Gillian Flynn', 'Gone Girl ', 3, 'suspense book', 'books/gone girl.jpg', 'book', 4),
(50, 6, 'By Robert Harries', 'An Officer & a Spy', 3, 'suspense book', 'books/an officer and a spy.jpg', 'book', 4),
(51, 6, 'By J.K. Rowling', 'Harry Potter & The Cursed Child', 4, 'fiction book', 'books/harry potter and the cursed child.jpg', 'book', 5),
(52, 6, 'By Marry Higgins Clark', 'The Cindrella Murder', 4, 'fiction book', 'books/The cindrella murer.jpg', 'book', 5),
(53, 1, 'High Heels', 'Ladies Shoes', 23, 'High Heels', 'women/shoes.jpg', 'shoes', 27),
(54, 6, 'By Lauren Willig', 'The English Wife', 3, 'book', 'books/the english wife.jpg', 'book', 4),
(55, 6, 'By Jassie Burton', 'The Miniaturist', 3, 'book', 'books/The-Miniaturist.jpg', 'book', 4),
(56, 6, 'By Stephen King', 'End of Watch', 3, 'book', 'books/end-of-watch.jpg', 'book', 4),
(57, 2, 'Nike', 'Sneakers', 60, 'jogging shoes', 'men/sneaker.jpg', 'shoes', 64),
(58, 3, 'Toddler', 'Strap Pants', 10, 'good fabrics', 'kids/Strap_pants.jpg', 'kids dress', 13),
(59, 7, 'Aquazone', 'Gents Watch', 25, '', 'jewelry/watch3.jpg', 'watch', 29),
(61, 7, 'Diamond World', 'Ear Rings', 100, '', 'jewelry/ear ring2.jpg', 'ear ring', 120),
(62, 2, 'Bata', 'Shoes', 25, 'leather shoes', 'men/shoe2.jpg', 'shoes', 29),
(63, 8, 'Singer', 'Food Processor', 25, 'grinds spices well', '/food processor.jpg', 'food processor', 28),
(64, 8, 'Singer', 'Food Processor', 25, 'grinds spices well', '/food processor.jpg', 'food processor', 28),
(65, 8, 'Singer', 'Food Processor', 25, 'grinds spices well', '/food processor.jpg', 'food processor', 28),
(66, 8, 'Singer', 'Food Processor', 25, 'grinds spices well', '/food processor.jpg', 'food processor', 28),
(67, 5, 'Nivea', 'Lotion', 3, 'Cherry Blossom Lotion', '/lotion.jpg', 'lotion', 4),
(68, 9, 'Aldo Handbags', 'Ladies Handbag', 56, 'high quality', '/purse.jpg', 'bags', 60),
(69, 9, 'Levis', 'Gents Wallet', 23, 'good leather ', '/wallet.jpg', 'wallet', 27),
(70, 9, 'New Look', 'Ladies Handbag', 45, 'Good quality', '/purse3.jpg', 'bags', 49),
(83, 9, 'Wild Horn', 'Gents Shoulder Bag', 30, 'good leather', '/gents_bag.jpg', 'bags', 35),
(84, 9, 'River Island', 'Purse', 24, '', '/purse5.jpg', 'bags', 27),
(85, 9, 'Gucci', 'Ladies Handbag', 34, 'good', '/purse2.jpg', 'bag', 38);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address`) VALUES
(1, 'Ridita', 'Akter', 'ridinakter@gmail.com', '8684a12b67089dddb15ceba589e0cf75', '0191774664', '332A Khilgaon, Tilpapara'),
(2, 'Safia', 'Akter', 'ia_ridita@yahoo.com', 'd06882e9cbebec860cbe6c47e6e4219e', '0181223468', '207/9 bashaboo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
