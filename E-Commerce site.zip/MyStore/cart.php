<?php


?>
<!DOCTYPE html>
<html>
	<head>
		<?php include 'includes/head.php'; ?>
		<style>
			 #TopHead{
			width: 100%;
			margin:50px auto 0px;
			margin-top: -1%;
			color:white;
			background: #db0f2d;
			text-align: center;
			border:1px solid #db0f2d;
			border-bottom: none;
			border-radius: 10px 10px 0px 0px;
			padding: 10px;
			font-size: 20px;
			font-style: italic;
			}


		</style>

	</head>
<body>
	<nav class="navbar navbar-inverse" id="HomeNav" id="cartNav">
    <div class="container-fluid">
      <ul class="nav navbar-nav">
        <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
        <li><a href="about.php"><span class="glyphicon glyphicon-exclamation-sign"></span> About</a></li>
        <li><a href="contact.php"><span class="glyphicon glyphicon-earphone"></span> Contact</a></li>
        <li style="width:300px;left:10px;top:10px;"><input type="text" class="form-control" id="search"></li>
        <li style="top:10px;left:20px;"><button class="btn btn-primary" id="search_btn">Search</button></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span>Cart<span class="badge">0</span></a>
          <div class="dropdown-menu" style="width:400px;">
            <div class="panel panel-success">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-md-3">Sl.No</div>
                  <div class="col-md-3">Product Image</div>
                  <div class="col-md-3">Product Name</div>
                  <div class="col-md-3">Price in $.</div>
                </div>
              </div>
              <div class="panel-body">
                <div id="cart_product"></div>
              </div>
              <div class="panel-footer"></div>
            </div>
          </div>
        </li>
      </ul>

    </div>
  </nav>
	
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="cart_msg">
				<!--Cart Message--> 
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading" id="TopHead">Cart Checkout</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-2 col-xs-2"><b>Action</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Image</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Name</b></div>
							<div class="col-md-2 col-xs-2"><b>Quantity</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Price</b></div>
							<div class="col-md-2 col-xs-2"><b>Price in $</b></div>
						</div>
						<div id="cart_checkout"></div>
					</div> 
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			
			
		</div>
</body>	
</html>
















		